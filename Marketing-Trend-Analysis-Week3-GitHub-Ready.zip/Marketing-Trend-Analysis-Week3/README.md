# Marketing Trend Analysis — Week 3

A complete Week 3 marketing analytics project focused on **trend analysis, exploratory data analysis (EDA), statistical testing, correlation analysis, anomaly detection, visual insights, and actionable recommendations**.

> **Project note:** The dataset used for this project does not contain a usable date/reporting-period field. Therefore, no artificial time series, monthly trend, or seasonal pattern has been created. The analysis focuses on the real patterns that can be supported by the available campaign, audience, spend, click, and conversion data.

## 📌 Project Overview

This project was completed as part of a marketing analytics training/internship workflow.

The objective was to move beyond basic data cleaning and visualization and answer practical questions such as:

- Which campaigns generate the most approved conversions?
- Which campaigns are more efficient based on CPA?
- How do CTR and conversion efficiency differ across campaigns?
- Which age groups and genders show different performance patterns?
- Which interests contribute meaningful conversion volume?
- Are important marketing metrics correlated?
- Are there unusual spend values or potential outliers?
- What statistical methods can be used to check whether observed differences are meaningful?
- What actions could a marketing team take from these findings?

## 📂 Repository Structure

```text
Marketing-Trend-Analysis-Week3/
│
├── Week_3_Trend_Analysis_and_Insights_Report_Futuristic.docx
├── Week_3_Trend_Analysis_and_Insights_Report_Expanded_v2.docx
├── Week_3_Trend_Analysis_Supporting_Analysis.xlsx
├── week3_trend_analysis.py
├── cleaned_marketing_campaign_data.csv
├── requirements.txt
├── README.md
│
└── visualizations/
    ├── 01_campaign_approved_conversions.png
    ├── 02_campaign_cpa.png
    ├── 03_campaign_ctr.png
    ├── 04_campaign_approved_cvr.png
    ├── 05_campaign_spend_vs_conversions.png
    ├── 06_age_approved_conversions.png
    ├── 07_age_ctr.png
    ├── 08_gender_cpa.png
    ├── 09_top_interest_conversions.png
    ├── 10_campaign_ctr_vs_cpa.png
    ├── 11_correlation_matrix.png
    └── 12_spend_outliers_boxplot.png
```

## 📊 Dataset

The project uses the cleaned marketing campaign dataset prepared during Week 1.

Key fields include:

- Campaign identifiers
- Facebook campaign identifiers
- Age group
- Gender
- Interest
- Impressions
- Clicks
- Spend
- Total conversions
- Approved conversions
- CTR
- CPC
- CPM
- Conversion rate
- CPA
- Spend in INR

The cleaned dataset contains **916 records**.

### Currency presentation

The source spend field is in USD. For presentation, the analysis uses a fixed conversion of:

**₹85 = US$1**

This is a presentation conversion used consistently in the report. It is not intended to represent historical exchange rates.

## 🔎 Analysis Performed

### 1. Exploratory Data Analysis

The analysis examines:

- Campaign scale
- Approved conversion volume
- CPA
- CTR
- Approved conversion rate
- Spend versus conversions
- Age-group performance
- Gender performance
- Interest-level conversion patterns

### 2. Correlation Analysis

Both **Pearson** and **Spearman** correlation methods are used.

This helps examine relationships between variables such as:

- Spend
- Impressions
- Clicks
- Conversions
- CTR
- CPA
- CPC
- CPM

Using both methods provides a broader view because Pearson focuses on linear relationships while Spearman evaluates monotonic relationships using ranks.

### 3. Statistical Testing

The project applies:

- **Kruskal–Wallis test** for comparing campaign groups
- **Mann–Whitney U test** for comparing gender-level CPA distributions

These non-parametric tests were selected because marketing metrics can be skewed and may not satisfy normality assumptions.

### 4. Outlier Analysis

The project uses the **IQR (Interquartile Range)** method to identify unusually high or low spend observations.

Outliers are treated as signals for investigation rather than automatically being considered errors.

## 📈 Visualizations

The project includes 12 visualizations covering:

1. Campaign approved conversions
2. Campaign CPA
3. Campaign CTR
4. Campaign approved conversion rate
5. Campaign spend versus conversions
6. Age-group approved conversions
7. Age-group CTR
8. Gender CPA
9. Top interests by conversions
10. Campaign CTR versus CPA
11. Correlation matrix
12. Spend outlier analysis

Each major graph in the report includes an explanation covering what the graph shows, what can be understood from it, why the finding matters, and an example of how the insight could be used.

## 💡 Key Analytical Themes

The report focuses on:

- Balancing scale and efficiency
- Identifying campaign-level performance differences
- Understanding audience behaviour
- Connecting engagement metrics with conversion outcomes
- Detecting unusual observations
- Using statistical evidence instead of relying only on visual differences
- Converting analytical findings into practical marketing actions

## ⚠️ Important Limitations

### No time/date field

The dataset does not contain a usable date or reporting-period column. Because of this, genuine:

- daily trends,
- weekly trends,
- monthly trends,
- year-over-year trends,
- seasonal patterns

cannot be calculated from this dataset.

No artificial dates were added.

### No revenue/profit field

The dataset contains spend and conversion information but does not provide reliable revenue or profit. Therefore, the analysis does **not** claim ROI or ROAS.

CPA and conversion-based measures are used instead.

### Association is not causation

Correlation does not prove that one marketing variable causes another. The statistical results are interpreted as evidence of association/difference, not as proof of causality.

## 🧪 Reproducibility

Install the required packages:

```bash
pip install -r requirements.txt
```

Run the analysis:

```bash
python week3_trend_analysis.py
```

The script documents the major analytical steps and generates the supporting analysis used in the project.

## 📁 Main Deliverables

| File | Purpose |
|---|---|
| `Week_3_Trend_Analysis_and_Insights_Report_Futuristic.docx` | Final visually enhanced report |
| `Week_3_Trend_Analysis_and_Insights_Report_Expanded_v2.docx` | Expanded analytical report |
| `Week_3_Trend_Analysis_Supporting_Analysis.xlsx` | Supporting calculations and analysis |
| `week3_trend_analysis.py` | Reproducible Python analysis |
| `cleaned_marketing_campaign_data.csv` | Dataset used for analysis |
| `visualizations/` | Generated charts and graphs |
| `requirements.txt` | Python dependencies |

## 🎯 Outcome

This Week 3 project demonstrates a complete analytical workflow:

**Real Dataset → Data Preparation → EDA → Statistical Analysis → Correlation → Outlier Detection → Visualization → Insights → Recommendations**

The focus is not only on producing charts, but on explaining what each result means and how a marketing team could use the evidence for decision-making.

## 👤 Author

**Gunjan Kumar**

BTech — Computer Science Engineering

---

### Suggested GitHub repository description

**Marketing Trend Analysis using Python — EDA, statistical testing, correlation analysis, outlier detection, visual insights, and actionable recommendations.**
